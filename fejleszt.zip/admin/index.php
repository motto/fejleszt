<?php 
header('Location:http://'.$_SERVER['HTTP_HOST'].'/fejleszt/index.php?com=admin');
<?php echo $keret->fejlec_general(); ?>
<link rel="stylesheet" type="text/css" href="alap.css">
<div class="top">
</div>
<div class="top2">
</div>
<div class="left">
</div>
<div class="center">
</div>
<div class="right">
</div>
<div class="bottom">
</div>
</body>
</html>


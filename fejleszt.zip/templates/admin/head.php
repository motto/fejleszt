<!DOCTYPE html>
<html dir="ltr" lang="hu-HU"><head><!-- Created by Artisteer v4.0.0.58475 -->
    <meta charset="utf-8">
    <title> <?php echo GOB::$param['title']; ?>	</title>
     <!--<meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="templates/admin/style.css" media="screen">
	<?php global $keret; $keret->fejlec_general();?>	

<style>.art-content .art-postcontent-0 .layout-item-0 { border-top-width:1px;border-top-style:solid;border-top-color:#B5C5C9;margin-top: 5px;margin-bottom: 5px;  }
.art-content .art-postcontent-0 .layout-item-1 { padding-right: 10px;padding-left: 10px;  }
.ie7 .post .layout-cell {border:none !important; padding:0 !important; }
.ie6 .post .layout-cell {border:none !important; padding:0 !important; }
</style></head>

	<body>
		<?php global $tartalom; echo $tartalom;?>
	</body>
</html>
<!DOCTYPE html>
<html dir="ltr" lang="hu-HU">
	<head>
		<meta charset="utf-8"/>
		<title> <?php echo GOB::$param['title'];?>	</title>
	   
		<?php global $keret;$keret->fejlec_general();?>  
	</head>

<!DOCTYPE html>
<html dir="ltr" lang="hu-HU"><head>
    <meta charset="utf-8"/>
    <title> <?php echo GOB::$param['title']; ?>	</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width"/>
    <link rel="stylesheet" href="templates/szovetseg3/style.css" media="screen"/>
    <link rel="stylesheet" href="templates/szovetseg3/style.responsive.css" media="all"/>
<?php global $keret; $keret->fejlec_general(); ?>   
<style>.art-content .art-postcontent-0 .layout-item-0 { padding-right: 10px;padding-left: 10px;  }
.ie7 .post .layout-cell {border:none !important; padding:0 !important; }
.ie6 .post .layout-cell {border:none !important; padding:0 !important; }

</style>
</head>

if(typeof(id2)==='undefined') id2 = 800;
//címsor---------------------------------------
window.location.pathname='index.hu';
$(location).attr('href','http://biokertek.infolapollk.hu');
<?php 
defined( '_MOTTO' ) or die( 'Restricted access' );
class Admin
{
$uj_sql="";
$frissit_sql="";




}

	
?>
 <?php 

if(isset($_GET['ftask'])){include 'inc/'.$_GET['ftask'].'.php';}
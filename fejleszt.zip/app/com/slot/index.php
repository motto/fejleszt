<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black" />

  <meta name="interface" content="desktop" />

  <title>Slots</title> 

  <link href='http://fonts.googleapis.com/css?family=Slackey' rel='stylesheet' type='text/css'/>
  <!--<link type="text/css" rel="stylesheet" href="css/reset.css" />-->
  <link type="text/css" rel="stylesheet" href="css/slot.css" />

</head>

</body>
</html>

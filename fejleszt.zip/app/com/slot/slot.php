<?php
global $title,$og_image,$og_description,$og_title,$og_url;

$title="Választási Játék!";
$og_title=$title;
$og_url=$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$og_image="http://menkuotto.infolapok.hu/media/62_1412437163_904.jpg";
$og_description="Egy kis lazításként írtam, de ha mélyen szántóbb akarnék lenni, hasonlíthatnám azok demokráciájára, akiket nem érdekel a politika."
?>


<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/hu_HU/all.js#xfbml=1&appId=218324098211541";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
  <div id="slot">
  <div class="cim">Jászberény választ!</div>
  
    <div id="jatek">
		  <div id="header">	
			<div class="cim2">pontszám:</div><div class="cim2" id="pontszam">0</div>
		  </div> 
		  <div id="ablak"> 
			<div id="sav1" class="sav" style=""><img style="margin:0px;"src="/com/slot/img/s_4.jpg" /></div>
			<div id="sav2" class="sav" style=""><img style="margin:0px;" src="/com/slot/img/s_11.jpg" /></div>
			<div id="sav3" class="sav" style=""><img style="margin:0px;" src="/com/slot/img/s_7.jpg" /></div>
			<div style="clear: both;"></div>

		  </div>
		
		  <div id="buttons">
				<div id="play" onclick="start_slot();" class="button button-default">Start</div>		  
		  </div>
	</div> 
	<div id="uzeno">Szövetség a változásért lista</div>
	
	<div id="vv"> 
		<div id="nev1" class="nev">Dr. Fodor Erzsébet 2.</div>
		<div id="nev2" class="nev">Dr. Gedei József 1. Polgármester jelölt</div>
		<div id="nev3" class="nev">Ménkű Ottó 3.</div> 
		
	</div> 

<div style="clear: both;"></div>
<div id="szoveg">
Ezt a játékot egy kis lazításként írtam.Ha mélyen szántóbb akarnék lenni, hasonlíthatnám azok demokráciájára, akiket nem érdekel a politika. Olyan külső körülmények döntik el, hogy neki jó lesz-e, amikre nem tud, és nem is akar hatással lenni. Szerencsére mi dönthetünk a sorsunkról. Nem csupán a gép előtt izgulhatunk, hogy győzzön a Szövetség a változásért! Október 12-én mi is tehetünk érte!<h1>Csak mi tehetünk érte!</h1></div> 
<div id="kep2" style="display: none;"></div>
<div id="kep3" style="display: none;"></div>
<div id="kozossegi" style="position:relative;top:-240px;">
<div class="fb-like" data-href="" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div>
<div class="fb-comments" data-href="http://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>" data-width="700" data-numposts="10" data-colorscheme="light"></div>
</div>
  </div>
 
  <script type="text/javascript" src="com/slot/js/sajat_slot.js"></script>
      <!-- 
	   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" ></script>
	  <input id="debug" type="button" value="Toggle Reels"/>  http://www.xvideos.com/video1774157/hairypussy_young_girl_forced_at_home -->

<?php
global $tmpl;
$tmpl='com/admin/template';
if(empty($task)){$task=$_GET['task'];}if ($task==''){$task='listaz';}

echo '<h3>dfdfdfgshshf</h3>';

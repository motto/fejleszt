<?php
//10403507-35004545-70070000
$modulid=21;
$lang_login=[
'21_data_changed'=>'Az adatok megváltoztak!',
'21 HAVE USER'=>'A <<0>> felhasználó név már foglalt!',
'21_passwd_nomatch'=>'A jelszó nem jó próbálja újra!'
];
LANG::$lang_tomb=array_merge(LANG::$lang_tomb, $lang_login);
Tomb::kiir([GOB::$hiba]);
$adatok['username']=GOB::get_user('username');
$adatok['email']=GOB::get_user('email');
//print_r($adatok);
$adatok=ADAT::postbol_datatomb(['oldpassword','password','password2','email','username'],$adatok);
ELL::$adatok=$adatok;
//print_r($adatok);
//LANG::ECH(['R_SZAM','Nk'],[['Szám medfgdző','NAGY']]); 
//LANG::ECH(['PASSWD','kis']);
//LANG::ECH(['PASSWD','Nkk']); 
//LANG::ech('MEZO=ERTEK',['password2','dghsdfghdg']);
function van_user($adatok,$sajat=''){
//már van ilyen felhasználó ---------------------------------
$sql="SELECT username FROM userek WHERE username='".ELL::$adatok['username']."'";
$van=DB::assoc_sor($sql);
if(!empty($van)){
	if($sajat!=''){if($sajat!=$van['username'] ){GOB::$hiba['ELL'][]=LANG::RET('21 HAVE USER',[ELL::$adatok['username']]);}
	}else{GOB::$hiba['ELL'][]=LANG::RET('21 HAVE USER',[ELL::$adatok['username']]);}
}
}
//adat mentés----------------------

function ment($adatok){
// aliasok a hibaüzeneteknek----------------
$p_alias=LANG::RET('PASSWD'); $p2_alias=LANG::RET('PASSWD').' '.LANG::RET('REPEAT');
$u_alias=LANG::RET('USER NAME');$e_alias=LANG::RET('EMAIL');
// a két jelszó mezőnek egyeznie kell------------------
ELL::SAME_2MEZO('MEZO=ERTEK',['password',[$p_alias,'Nk']],['password2',$p2_alias]);
//string hosz vizsgálat----------------------------
ELL::TOBB_STR_HOSSZ('R_MIN_MAX',[['password',$p_alias],['email',$e_alias],['username',$u_alias]],6,50);
//mail ellenőrzés-----------------------------
ELL::REG_EX('R_MAIL',['email']);
//csak magyar betúk szóközzel---------------------------
ELL::REG_EX('R_HU_TOBB_SZO',['username',$u_alias]);
//kiíratás adatbázis művletek csak jó adatokkal megyünk tovább ha nincs 'R_TOBB_SZO' vagy egyéb tisztító függvény  back slashalni kell-----------------------------
van_user($adatok);
$jelszo = md5(ELL::$adatok['password']);

if(empty(GOB::$hiba['ELL'])){
	$sql="INSERT INTO userek( username,email,password,registerdate) VALUES ('".ELL::$adatok['username']."','".ELL::$adatok['email']."','".$jelszo."',NOW())";
	$insert_id=DB::beszur($sql);
		if($insert_id>0){LANG::ECH('REG SUCCESFULL');
		include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'belep_form.php';
		}else{
		LANG::ECH('DATA ERROR,REPEAT');
		include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'regisztral_form.php';}
	}else{
	include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'regisztral_form.php';
	}
}
function vment($adatok){
// aliasok a hibaüzeneteknek----------------
$p_alias=LANG::RET('NEW PASSWD'); $p2_alias=LANG::RET('NEW PASSWD').' '.LANG::RET('REPEAT');
$u_alias=LANG::RET('USER NAME');$e_alias=LANG::RET('EMAIL');
// a két jelszó mezőnek egyeznie kell------------------
if($adatok['password']!=''){ELL::SAME_2MEZO('MEZO=ERTEK',['password',[$p_alias,'Nk']],['password2',$p2_alias]);}
//string hosz vizsgálat----------------------------
if($adatok['password']!=''){ELL::TOBB_STR_HOSSZ('R_MIN_MAX',['password',[$p_alias,'Nk']],6,50);}
ELL::TOBB_STR_HOSSZ('R_MIN_MAX',[['email',$e_alias],['username',$u_alias]],6,50);
//mail ellenőrzés-----------------------------
ELL::REG_EX('R_MAIL','email');
//csak magyar betúk szóközzel---------------------------
ELL::REG_EX('R_HU_TOBB_SZO',['username',$u_alias]);
//kiíratás adatbázis művletek csak jó adatokkal megyünk tovább ha nincs 'R_TOBB_SZO' vagy egyéb tisztító függvény  back slashalni kell-----------------------------
van_user($adatok,GOB::get_user('username')); //a saját usernevét nem veszi figyelembe
$jelszo = md5(ELL::$adatok['oldpassword']);
$sql="SELECT password FROM userek WHERE username='".GOB::get_user('username')."'";
$dd=DB::assoc_sor($sql);
if($jelszo!=$dd['password']){GOB::$hiba['ELL'][]=LANG::RET('21_passwd_nomatch');}
if(empty(GOB::$hiba['ELL'])){
if($adatok['password']!=''){$uj_jelszo=md5(ELL::$adatok['password']);}else{$uj_jelszo=$jelszo;}
	DB::parancs("UPDATE userek SET username='".ELL::$adatok['username']."',email='".ELL::$adatok['email']."',password='".$uj_jelszo."' where id='".GOB::get_user('id')."'");
	LANG::ECH('DATA_CHANGED');
	include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'belep_form.php';
	}else{
	Tomb::kiir(GOB::$hiba['ELL']);
	
	include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'valtoztat_form.php';
	}
	
}


switch ($_GET['login']){
	case 'reg':
	include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'regisztral_form.php';
		break;
	case 'valtoztat':
	include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'valtoztat_form.php';
		break;
	case 'vment':
		vment($adatok);
		break;			
	case 'ment':
		ment($adatok);
		break;
	default: 
	if($_SESSION['userid']>0)
		{include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'belepve_form.php';}
		else
		{include 'app'.DS.'modulok'.DS.'login'.DS.'wiev'.DS.'belep_form.php';}	
	}

Tomb::kiir([GOB::$hiba]);
//print_r(GOB::$hiba['ELL']);
?>